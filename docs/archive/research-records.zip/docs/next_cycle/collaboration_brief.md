> Closed scientific record. Dated execution and authorization statements below describe historical work. New model development follows [root plan.md](../../plan.md).

# Crossed combination-response measurement brief

## Current direction, 15 October 2026

The sole forward-looking plan is [root plan.md](../../plan.md). The [evidence audit](../frontier/evidence_audit_20261015.md) and [independent precision protocol](../frontier/measurement_precision_next.md) supersede the dated program below. No predictor is nominated; the next objective is actual independent culture/reference precision, with rights, lineage, margin/power and assay-cost review still missing.

## Historical program snapshot

## Current successor status, 13 October 2026

The second-council `opal_context_contrast_v1` pipeline is implemented, with software checks only. The active plan/contract and [implementation guide](../frontier/context_contrast_implementation.md) supersede the historical bridge instructions below. SC01–SC08 now have executable qualification, preparation, contrast/reference/control fitting, sealed evaluation and readiness components. The fixed-context diagnostic uses both observed TNF contexts in training and no target bridges. Its numerical preparation, fitting and biological scoring require separate owner acceptance; independent confirmation remains unqualified. Frozen bridge configuration/results, old thresholds and failed attempts remain unchanged.

This is a reviewable laboratory design brief, not a sent message, collaboration agreement, assay order or powered study. The active program is [../../plan.md](../../plan.md). The previous fixed-state brief is preserved at [../frontier/historical/collaboration_brief_before_frontier_20261011.md](../frontier/historical/collaboration_brief_before_frontier_20261011.md).

The scientific question is whether a sparse pair screen in a new pretreatment-defined context reveals reproducible composition information that transfers to globally unmeasured pairs beyond shared expression calibration. We need crossed pair/context measurements and independently initiated cultures, not additional sample labels or cells from one culture.

An illustrative workload uses twelve interventions with 66 possible pairs, forty source-training identities, six bridge candidates and twenty globally withheld query identities. Exactly four bridge identities form the primary adaptation budget. A source variance pilot can use three source contexts and three independent initiations per context, with matched controls, twelve exact singles and 46 nonquery pair conditions, totaling 59 conditions per culture or 531 condition assays before extra control/technical repeats. Target confirmation uses four bridges plus twenty query pairs, twelve singles and controls, or 37 conditions per culture before extra replication. The final culture/context numbers require empirical covariance, useful margin, power and assay quotation; these illustrative quantities are not a powered design or a requirement to start with a large screen.

A smaller nonquery measurement pilot may establish precision first under a separately frozen contract. Preserve query identities in independent custody, keep source pair outcomes for those identities unavailable to fitting/selection, and do not choose an interaction panel because its exposed pilot outcomes look strong. Source contexts and target contexts must have independently randomized plate/block allocation so context does not alias assay batch.

Required provenance includes independent initiation timestamps and culture lineage, cell model/passage/lot, pretreatment context, exact guide/reagent identity, physical single and pair doses/vehicles, treatment order and duration, randomized wells/blocks, shared control/single match IDs, extraction/library/run, normalization, gene schema, missingness and complete prior access. Contexts based on post-treatment cell classifications are not substituted for pretreatment states. Technical wells, sequencing lanes and resampled cells do not establish independent culture repetition.

The primary measurement gate asks whether pair-specific departures repeat beyond shared affine/incidence effects at a collaborator-defined useful margin. Estimate shared-control/single covariance and procedure precision, review null error/interval coverage and power, then choose final confirmation allocation. Compare the value of spending additional assays on bridge pairs versus independent reference precision when feasible. A cheap RNA endpoint can support a population-mean prediction claim; distributional or functional claims require their corresponding measured endpoints.

No assay price, collaborator availability, biological margin, confirmation culture count or delivery date is known. Those are concrete external dependencies. Code can produce a specification and audit it; code cannot supply independent cultures or an agreement. The prospective utility stage freezes a transcriptomic program and model/reference shortlists before new outcomes, with an independent functional assay if the claim concerns biological action.
