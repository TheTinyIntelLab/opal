# Frontier execution delivery

The finite registered program is complete and failed its all-task scientific gate. Completion remains the strongest model in this menu on the six exposed growth cohorts, with Jurkat below the required5% gain. The [growth report](growth_results.md) gives every baseline, conditional sensitivity and failed criterion. The [synthetic report](synthetic_results.md) separates recoverable ground truth from biological validation. COLO1 remains unqualified, with the missing companion evidence and closed403 route in the [source prerequisite report](Grok_source_prerequisite_v1.md).

## Engineering evidence

The final full suite passed1158 tests with one preserved strict expected historical failure and six warnings. The final wheel and sdist built. The wheel was installed outside the checkout and all105 runtime Python files matched the experiment installation byte-for-byte. All840 growth and5376 synthetic checkpoints had already replayed exactly from the external installed package, without fitting; final packaging introduced no runtime changes. This is pinned-stack replay, not a clean local dependency environment. Hosted CI separately installs dependency closures.

The local docs build checked317 pages with zero unavailable local links before this closeout and the independent result-review page were added. A final documentation receipt records the completed page count. The custody audit checked144 frozen file bindings, and only `.gitattributes`, README and the live plan changed among files tracked at the original69fd675 commit. Historical model/evaluator code, results, tolerances and checkpoints remain unchanged. The legacy1e-12 prediction compatibility gate remains unresolved.

The delivery runner passed available original/external/reset/block replays, the count-assay rehearsal and both installed synthetic model series. Fresh native/reagent/flexible/budget/wave-three replay paths remain blocked by missing historical E: assets. The runner's unsupplied duplicate tournament stage is distinct from the separate passing installed tournament replay. No absent asset is reported as checked. Existing unrelated host dependency conflicts were recorded and left unchanged.

## Preserved failures and attribution

The first baseline command used a relative interpreter and failed before pytest; the corrected invocation passed1088 tests. The first independent fixture run exposed Windows path separator drift; root fixed prospective lifecycle path normalization, and20 fixtures then passed. The first pilot fit preceded independent acceptance and remains unscored/unqualified. A fresh pilot lifecycle qualified before the full synthetic run. Growth-v1 and v2 resource qualifications failed and remain preserved; the lossless v3 codec passed the same caps before biological loading. None of these changes modifies a scored model, split or acceptance threshold.

The original four-worker hierarchy produced proposals/critiques/revisions. A later stopped at provider capacity; C did not audit implementation that did not yet exist. Additional user-authorized Cursor Grok rounds authored fixtures/delivery tooling, source continuation, growth adapter and packing. Root reviewed/corrected delegated code and ran the full experiments. A separate fresh [Grok result audit](Grok_results_review.md) completed and root [accepted its limitations](root_results_response.md). It confirms the failed gate and custody, without a response-level independent reproduction. Historical summary-table exposure is retained in the ledger; no claim of complete absence of biological numbers is made.

## What remains

No all-task model is promoted, and no new independent biological source is qualified. A primary guide-ID/sequence/target/control companion, annotation construction lineage and time/culture/initiation join can unlock COLO1 qualification; the already failed endpoint is not retried. Source-specific registration must precede any response header or value access. More fitting on these now-scored development tasks cannot rescue the failed registered question. Missing historical custody is the separate engineering blocker. Commit, remote SHA, clean-tree and hosted-check verification are recorded at delivery time, separately from scientific acceptance.

## Committed-byte custody

The final Git-object audit found120 unique bound files byte-exact in Git and14 historical working files whose recorded CRLF bytes differ from their LF Git blobs. Every difference is explained exactly by replacing LF with CRLF; there are no unexplained differences. The experiment bindings correctly hash the actual executed/installed working bytes. `committed-custody-v1.json` records both hashes and the reversible reconstruction for a new scratch checkout. Historical source blobs, working files, checkpoints and tolerances are unchanged. New frozen frontier files retain their exact bytes through Git attributes. This is a pinned-stack reconstruction record, not a claim that the original bindings match every platform checkout without reconstruction.

## Follow-up after65f32b3

The [completion audit](plan_completion_audit.md) closes remaining executable gaps. In particular, the available historical budget branch now replays all1020 checkpoints independently of the missing E: reagent/flexible prerequisites. Earlier statements about the combined verifier describe that preserved command, not the availability of the budget assets. Native/reagent/flexible/wave-three missing-custody blockers persist. New design guards and static processing projections do not alter the frozen models, biological scores or failed gate.
