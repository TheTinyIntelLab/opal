# Local release audit, 15 October 2026

Current external-validation phase: see [source decisions](external_validation_sources.md) and [outreach status](outreach_status.md). Four source-specific inquiries were pursued in five send attempts; one address bounced and was rerouted. Delivery of the other four, substantive responses, agreements and biological validation are not established. The bounded GSE95153 repeat diagnostic is complete and descriptive; context-contrast stays paused and readiness remains 0/14. Earlier no-contact statements below describe the preceding dated closeout.

This checkout is a local review artifact, not a published successor biological predictor. Root `plan.md` governs forward work; `evidence_audit_20261015.md` records verification scope and unresolved issues.

| Asset | Evidence available | Remaining restriction |
| --- | --- | --- |
| Successor code | Frozen contract/config, implementation, source refusal, fixture tests and complete proposed inventory | Real fitting/evaluation absent; complete numerical envelope unprofiled; independent confirmation absent |
| Crossed-single states/predictions | Preparation, 684 attempts, per-fold manifests, safe arrays, seal, metrics and reproduced selections/replays | Primary assets local; filter failed; no useful-effect nomination or blanket weight-export approval |
| GxE data/measurements | Five official file receipts, local raw SHA checks, preserved attempts, all 66 row records | Export licence/hash-field semantics unresolved; recovered aggregates and panel variance are retained/hash-verified locally; technical units only |
| Historical bridge/evidence | All 5,142 inventory entries present and hash-matched, original frozen config/PDF retained | Protected historical evaluators/refitting not reopened; no new biological certification |
| Paper/docs/package | Current TeX/tables/figures, dated build hashes, local tests and builds | Offline review build; no publication, remote CI or external review claimed |

The corrected sci-Plex and PertSpectra deposits have explicit CC-BY-4.0 terms in inspected records. Source code and article terms are distinct. MIT GxE author code does not license the dataset. These source terms do not establish legal approval for all derivatives, weights or public distribution. Before recommending release, resolve dependency/source notices, source-specific data/measurement/weight permissions and any institutional consent. No package/model/data upload, release tag or push was performed.

A clean source checkout cannot replay all scores without local source/inference assets and their rights. The new audit CLI refuses existing outputs, verifies path/hash custody, uses NPZ without pickle and never fits/downloads or creates owner/reviewer approvals. Its bounded envelope is separate from scientific budgets. Missing assets, overlapping query populations, nonfinite predictions or mismatched selections fail replay. The numerical claim map is a traceability aid, not blanket scientific certification.

Final local closeout: v2 recovery, reference-only panel and all 66 endpoint rows reproduce within the original envelope. Historical plans are retained in Git but excluded from source archives; the development citation identifies 0.1.3.dev0 without inventing a release date/tag. Current test/build and package content evidence is `workstream_closeout_validation.json`. Remote CI, publication and source-specific export approval are not claimed.
