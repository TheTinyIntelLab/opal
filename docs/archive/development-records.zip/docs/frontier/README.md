# Closed frontier research record

The October 20 [research reset](../research_reset/summary.md) and [root plan](../../plan.md) govern new work. All programs and forward-looking language below are preserved historical snapshots, not active experiment queues.

The current model-development objective and failed composition candidate are documented in [the decision report](../model_development_20261020.md). The dated records below preserve earlier findings; they do not supply an active backlog.

## Closed direction, 15 October 2026

The sole forward-looking plan is [root plan.md](../../plan.md). The [evidence audit](../frontier/evidence_audit_20261015.md) and [independent precision protocol](../frontier/measurement_precision_next.md) supersede the dated program below. No predictor is nominated; the next objective is actual independent culture/reference precision, with rights, lineage, margin/power and assay-cost review still missing.

## External evidence phase

[Current source decisions](external_validation_sources.md) record three new metadata reviews and the executed small source-labelled repeat diagnostic. [Outreach](outreach_status.md) records four actual sent inquiries with no confirmed delivery/reply/agreement. All 14 gates remain failed and no predictor was fitted.

## Current evidence and reproduction

[The closed workstream](workstream_closeout.md) records successful full GxE recovery/panel/endpoint replay and the preserved earlier failure. [Reproduction](reproducibility_closeout.md) specifies required local assets and fixture-only checks. The former plan selected independent reference/culture precision; that remains an unmet biological requirement, not the current model-development assignment. Context-contrast is paused; no model is nominated and readiness remains 0/14. Source incompatibility is not biological failure.

## Historical program snapshot

The current successor is the implemented, unrun [`opal_context_contrast_v1` pipeline](context_contrast_implementation.md). Its [active council plan](../../plan.md), [contract](experiment_contract.md) and [handoff](implementation_handoff.md) fix a two-observed-context diagnostic with globally withheld pairs and no target bridges. The guide supplies executable commands, the full resource inventory, software validation and remaining authorization/evidence requirements. Preparation, scientific fitting and biological scoring have not run; independent biological confirmation and frontier superiority remain unestablished.

The frozen bridge configuration, original results, failed attempts and 207/256-gene refusal remain preserved. Its retirement changes the research default, without establishing biological failure. The earlier program introduction below is a historical snapshot, not the active numerical procedure.

## Preserved first-council introduction

The former integrated scientific specifications remain in historical/. The current [root plan](../../plan.md) governs new work. The prior plan is preserved at [historical/plan_before_frontier_20261011.md](historical/plan_before_frontier_20261011.md); its uncompleted checkboxes are not a second active experiment queue.

The [current-state audit](current_state_audit.md) and [audit manifest](audit_manifest.json) distinguish inspected artifacts from manuscript claims and proposed work. The [experiment contract](experiment_contract.md) defines the one first study, and the [implementation handoff](implementation_handoff.md) gives the coding work and acceptance criteria. Neither document is a claim that a new scientific experiment has run.

Seven independently assigned specialist reports are in `reviews/`. Their initial conclusions and later cross-examination are retained. The final synthesis resolves disagreements through scientific criteria rather than voting.

This program preserves the observed-single reference system and historical negative outcomes. Its proposed successor learns from crossed pair/context measurements and a small declared budget of target-context bridge pairs. A few-shot context is not an entirely unobserved context, and no measured reference budget may be omitted from a frontier claim.
