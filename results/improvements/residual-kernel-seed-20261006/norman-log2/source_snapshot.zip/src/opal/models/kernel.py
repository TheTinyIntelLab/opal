"""Symmetric residual kernels with a shared offset and development-only tuning."""
import numpy as np
from scipy.linalg import solve


def single_kernel(singles, kind='rbf', bandwidth=1.0):
    x = np.asarray(singles, dtype=np.float64)
    gram = x @ x.T
    if kind == 'linear':
        return gram / max(float(np.trace(gram) / len(x)), 1e-12)
    distance = np.maximum(np.diag(gram)[:, None] + np.diag(gram)[None, :] - 2 * gram, 0)
    positive = distance[np.triu_indices(len(x), 1)]
    scale = max(float(np.median(positive[positive > 0])) if np.any(positive > 0) else 1, 1e-12)
    return np.exp(-distance / (scale * bandwidth))


def symmetric_kernel(single_gram, left, right, interaction=False):
    a, b = np.asarray(left).T
    c, d = np.asarray(right).T
    ac, ad = single_gram[np.ix_(a, c)], single_gram[np.ix_(a, d)]
    bc, bd = single_gram[np.ix_(b, c)], single_gram[np.ix_(b, d)]
    return (ac * bd + ad * bc) / 2 if interaction else (ac + ad + bc + bd) / 4


def global_kernel(singles, pairs):
    additive = singles[pairs[:, 0]] + singles[pairs[:, 1]]
    # Reference-only scale, so outer/inner response holdouts cannot fit it.
    scale = np.maximum(np.std(singles, axis=0) * np.sqrt(2), 1e-6)
    x = additive / scale
    return x @ x.T / x.shape[1]


def smoother(kernel, train, query, alpha):
    """Return query-to-training weights, including an unpenalized intercept."""
    k = np.asarray(kernel[np.ix_(train, train)], np.float64)
    cross = np.asarray(kernel[np.ix_(query, train)], np.float64)
    column_mean = k.mean(0)
    centered = k - column_mean[None, :] - column_mean[:, None] + k.mean()
    cross = cross - column_mean[None, :] - cross.mean(1)[:, None] + k.mean()
    weights = solve(centered + alpha * np.eye(len(train)), cross.T, assume_a='pos').T
    return weights - weights.mean(1)[:, None] + 1 / len(train)


def prediction_error(weights, train, query, residual_gram):
    """Exact equal-pair MSE in gene units without reconstructing every candidate."""
    yy = residual_gram[np.ix_(train, train)]
    cross = residual_gram[np.ix_(query, train)]
    error = np.einsum('ij,jk,ik->i', weights, yy, weights)
    error += np.diag(residual_gram)[query] - 2 * np.sum(weights * cross, axis=1)
    return float(np.mean(error))
